# Kob1Kenobi.github.io
Synerdy App, the first comic book app in South Africa.
